import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';

import Cardapio from './src/components/cardapio';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Cardapio />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
});