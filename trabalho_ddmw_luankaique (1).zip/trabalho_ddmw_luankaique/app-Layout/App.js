import React, { useState } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';

import Cardapio from './src/components/cardapio';
import Carrinho from './src/components/carrinho';

export default function App() {
  const [telaAtual, setTelaAtual] = useState('T1'); // 'T1' (Cardápio) ou 'T2' (Carrinho)
  const [carrinho, setCarrinho] = useState([]);

  // Adicionar item vindo do Cardápio
  const adicionarAoCarrinho = (produto) => {
    setCarrinho((prev) => {
      const itemExiste = prev.find((item) => item.id === produto.id);
      if (itemExiste) {
        return prev.map((item) =>
          item.id === produto.id ? { ...item, quantidade: item.quantidade + 1 } : item
        );
      }
      return [...prev, { ...produto, quantidade: 1 }];
    });
  };

  // Alterar quantidade ou remover no Carrinho (RF07)[cite: 1, 2]
  const alterarQuantidade = (id, delta) => {
    setCarrinho((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const novaQtd = item.quantidade + delta;
            return novaQtd > 0 ? { ...item, quantidade: novaQtd } : null;
          }
          return item;
        })
        .filter(Boolean)
    );
  };

  // Contadores e Cálculos (RF03, RF08)[cite: 1, 2]
  const totalItens = carrinho.reduce((sum, item) => sum + item.quantidade, 0);
  const subtotal = carrinho.reduce((sum, item) => sum + item.preco * item.quantidade, 0);
  const TAXA_ENTREGA = 6.00;
  const totalGeral = subtotal > 0 ? subtotal + TAXA_ENTREGA : 0;

  return (
    <SafeAreaView style={styles.container}>
      {telaAtual === 'T1' ? (
        <Cardapio
          onAdicionarItem={adicionarAoCarrinho}
          totalItens={totalItens}
          onAbrirCarrinho={() => setTelaAtual('T2')}
        />
      ) : (
        <Carrinho
          carrinho={carrinho}
          onAlterarQtd={alterarQuantidade}
          subtotal={subtotal}
          taxaEntrega={TAXA_ENTREGA}
          totalGeral={totalGeral}
          onVoltar={() => setTelaAtual('T1')}
          onContinuar={() => alert('Indo para a próxima tela: Checkout (T3)')}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
});